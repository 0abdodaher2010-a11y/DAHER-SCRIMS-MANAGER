# DAHER SCRIMS MANAGER

This is the first Flutter UI prototype for the Android app.

## What is included
- Arabic RTL interface
- Dark esports theme with gold and purple accents
- Home, Scrims, Results, and Account tabs
- Starter dashboard and empty states

## Important
This is a UI starter, not the complete online app yet. Authentication, cloud database,
image storage, organizer approvals, team registration, lobby assignment, scoring,
and results-image export still need implementation and testing.

## Run
1. Install Flutter SDK and Android Studio.
2. Create/open this project folder.
3. Run `flutter pub get`.
4. Run `flutter run` on an Android device or emulator.
5. To build an APK after testing: `flutter build apk --release`.
