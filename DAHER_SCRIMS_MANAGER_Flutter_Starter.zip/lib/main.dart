import 'package:flutter/material.dart';

void main() => runApp(const DaherApp());

const gold = Color(0xFFD6AD45);
const purple = Color(0xFF8B5CF6);
const bg = Color(0xFF090A0E);
const panel = Color(0xFF171922);

class DaherApp extends StatelessWidget {
  const DaherApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'DAHER SCRIMS MANAGER',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: const ColorScheme.dark(
          primary: gold, secondary: purple, surface: panel,
        ),
        fontFamily: 'Roboto',
        useMaterial3: true,
      ),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int tab = 0;
  final pages = const [HomePage(), ScrimsPage(), ResultsPage(), AccountPage()];
  final titles = ['الرئيسية', 'السكر يمات', 'النتائج', 'حسابي'];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: bg,
          title: const Text('DAHER  •  SCRIMS MANAGER',
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.w900, letterSpacing: .5)),
          actions: const [Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Icon(Icons.emoji_events_outlined, color: gold),
          )],
        ),
        body: SafeArea(child: pages[tab]),
        bottomNavigationBar: NavigationBar(
          backgroundColor: panel,
          indicatorColor: gold.withOpacity(.18),
          selectedIndex: tab,
          onDestinationSelected: (v) => setState(() => tab = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.sports_esports_outlined), selectedIcon: Icon(Icons.sports_esports), label: 'السكر يمات'),
            NavigationDestination(icon: Icon(Icons.leaderboard_outlined), selectedIcon: Icon(Icons.leaderboard), label: 'النتائج'),
            NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'حسابي'),
          ],
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: const LinearGradient(colors: [Color(0xFF29200D), Color(0xFF171922)]),
          border: Border.all(color: gold.withOpacity(.45)),
        ),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('DAHER SCRIMS MANAGER', style: TextStyle(color: gold, fontSize: 20, fontWeight: FontWeight.w900)),
          SizedBox(height: 8),
          Text('منصتك لتنظيم سكر يمات PUBG MOBILE', style: TextStyle(color: Colors.white70)),
          SizedBox(height: 18),
          Text('نظّم • نافس • تصدّر', style: TextStyle(fontWeight: FontWeight.bold)),
        ]),
      ),
      const SizedBox(height: 18),
      const Row(children: [
        Expanded(child: StatCard(label: 'كل السكر يمات', value: '0', icon: Icons.sports_esports)),
        SizedBox(width: 10),
        Expanded(child: StatCard(label: 'مفتوحة', value: '0', icon: Icons.lock_open)),
        SizedBox(width: 10),
        Expanded(child: StatCard(label: 'الفرق', value: '0', icon: Icons.groups)),
      ]),
      const SizedBox(height: 24),
      const SectionTitle('السكر يمات القادمة'),
      const SizedBox(height: 10),
      const EmptyCard(icon: Icons.event_busy, title: 'لا توجد سكر يمات حالياً', subtitle: 'ستظهر هنا المواعيد القادمة بعد إضافتها'),
      const SizedBox(height: 20),
      const SectionTitle('اختصارات'),
      const SizedBox(height: 10),
      const Row(children: [
        Expanded(child: ShortcutCard(icon: Icons.add_circle_outline, title: 'إنشاء سكر يم')),
        SizedBox(width: 10),
        Expanded(child: ShortcutCard(icon: Icons.groups_outlined, title: 'تسجيل فريق')),
      ]),
    ],
  );
}

class StatCard extends StatelessWidget {
  final String label, value;
  final IconData icon;
  const StatCard({super.key, required this.label, required this.value, required this.icon});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16), border: Border.all(color: Colors.white10)),
    child: Column(children: [
      Icon(icon, color: gold, size: 20),
      const SizedBox(height: 8),
      Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
      Text(label, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white60, fontSize: 11)),
    ]),
  );
}

class SectionTitle extends StatelessWidget {
  final String title;
  const SectionTitle(this.title, {super.key});
  @override
  Widget build(BuildContext context) => Text(title, style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold));
}

class EmptyCard extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  const EmptyCard({super.key, required this.icon, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(24),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(18)),
    child: Column(children: [
      Icon(icon, color: Colors.white38, size: 34),
      const SizedBox(height: 10),
      Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
      const SizedBox(height: 5),
      Text(subtitle, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white54, fontSize: 12)),
    ]),
  );
}

class ShortcutCard extends StatelessWidget {
  final IconData icon;
  final String title;
  const ShortcutCard({super.key, required this.icon, required this.title});
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(16)),
    child: Column(children: [Icon(icon, color: purple), const SizedBox(height: 8), Text(title, style: const TextStyle(fontWeight: FontWeight.bold))]),
  );
}

class ScrimsPage extends StatelessWidget {
  const ScrimsPage({super.key});
  @override
  Widget build(BuildContext context) => const Padding(
    padding: EdgeInsets.all(16),
    child: EmptyCard(icon: Icons.sports_esports, title: 'قائمة السكر يمات', subtitle: 'هنا هتظهر السكر يمات بعد ربط قاعدة البيانات وإضافة أول سكر يم.'),
  );
}

class ResultsPage extends StatelessWidget {
  const ResultsPage({super.key});
  @override
  Widget build(BuildContext context) => const Padding(
    padding: EdgeInsets.all(16),
    child: EmptyCard(icon: Icons.leaderboard, title: 'النتائج والترتيب', subtitle: 'هنا هيظهر ترتيب الفرق والقتلات والنقاط لكل بطولة.'),
  );
}

class AccountPage extends StatelessWidget {
  const AccountPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: const [
    EmptyCard(icon: Icons.account_circle_outlined, title: 'حساب المستخدم', subtitle: 'تسجيل الدخول والصلاحيات هيتضافوا في مرحلة ربط الحسابات.'),
    SizedBox(height: 14),
    ListTile(leading: Icon(Icons.admin_panel_settings, color: gold), title: Text('طلب صلاحية منظم')),
    ListTile(leading: Icon(Icons.info_outline, color: purple), title: Text('عن DAHER SCRIMS MANAGER')),
  ]);
}
